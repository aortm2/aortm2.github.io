goog.require('tvs.AnnotatorCore');
goog.require('tvs.Annotator');
goog.require('tvs.AnnotatorDictionary');
